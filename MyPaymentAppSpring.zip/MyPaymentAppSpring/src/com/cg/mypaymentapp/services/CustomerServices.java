package com.cg.mypaymentapp.services;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.mypaymentapp.beans.Customer;
import com.cg.mypaymentapp.exceptions.InsufficientBalanceException;
import com.cg.mypaymentapp.exceptions.InvalidInputException;



public interface CustomerServices {
	



	public Customer fundTransfer(String sourceMobileNo, String targetMobileNo, BigDecimal amount) throws InvalidInputException, SQLException;

	public Customer depositAmount(String mobileNo, BigDecimal amount) throws InvalidInputException, SQLException;

	public Customer withdrawAmount(String mobileNo, BigDecimal amount) throws InsufficientBalanceException, SQLException;
	

	public Customer createAccount(Customer customer);
;

	public Customer showBalance(String mobileNo);
	
}