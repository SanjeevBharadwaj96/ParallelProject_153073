package com.cg.mypaymentapp.beans;

import java.math.BigDecimal;

import javax.persistence.CascadeType;
import javax.persistence.Embeddable;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

@Entity

public class Customer {
	
	@NotNull
	private String name;

	@Id
	@Size(max=10, message="enter 10 digit mobile number")
	@Pattern(regexp="(0/91)?[7-9][0-9]{9}", message="enter valid mobile number")
	private String mobileNo;
@Embedded
	private Wallet wallet;

	public Customer(String name2, String mobileNo2, Wallet wallet2) {
		this.name = name2;
		this.mobileNo = mobileNo2;
		this.wallet = wallet2;
	}

	public Customer() {
		
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public Wallet getWallet() {
		return wallet;
	}

	public void setWallet(Wallet wallet) {
		this.wallet = wallet;
	}

	@Override
	public String toString() {
		return "Customer name=" + name + ", mobileNo=" + mobileNo + wallet;
	}

}
