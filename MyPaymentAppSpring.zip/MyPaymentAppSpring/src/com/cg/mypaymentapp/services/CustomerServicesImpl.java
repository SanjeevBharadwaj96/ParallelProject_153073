package com.cg.mypaymentapp.services;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.mypaymentapp.beans.Customer;
import com.cg.mypaymentapp.beans.Wallet;
import com.cg.mypaymentapp.daoservices.WalletRepoImpl;
import com.cg.mypaymentapp.exceptions.InsufficientBalanceException;
import com.cg.mypaymentapp.exceptions.InvalidInputException;

@Component(value = "customerServices")
public class CustomerServicesImpl implements CustomerServices {

	@Autowired
	private WalletRepoImpl repo;

	Scanner console = new Scanner(System.in);

	@Transactional
	@Override
	public Customer createAccount(Customer customer) {

		int id = (int) (Math.random() * 100);
		Wallet wallet = new Wallet();
		wallet.setWalletId(id);
		wallet.setBalance(customer.getWallet().getBalance());
		customer.setWallet(wallet);
		return repo.save(customer);
	}


	@Override
	public Customer showBalance(String mobileNo) {
		Customer customer = repo.findOne(mobileNo);
		System.out.println(customer);
		return customer;
	}

	public Customer fundTransfer(String sourceMobileNo, String targetMobileNo, BigDecimal balance)
			throws InvalidInputException, SQLException {
		try {
			Customer customer21 = repo.findOne(sourceMobileNo);
			Customer customer22 = repo.findOne(targetMobileNo);
			if ((customer21 != null) && (customer22 != null)) {
				Customer wcustomer = withdrawAmount(sourceMobileNo, balance);
				Customer dcustomer = depositAmount(targetMobileNo, balance);
				System.out.println(customer21);
				return dcustomer;
			}

		} catch (InvalidInputException e) {
			throw new InvalidInputException();
		}
		return null;
	}

	public Customer depositAmount(String mobileNo, BigDecimal balance) throws InvalidInputException, SQLException {
		Customer dcustomer = repo.findOne(mobileNo);
		try {
			if (dcustomer != null) {
				Wallet iAmount = dcustomer.getWallet();
				int id = iAmount.getWalletId();
				BigDecimal updatedBalance = iAmount.getBalance().add(balance);
				Wallet wallet = new Wallet(updatedBalance, id);
				dcustomer.setWallet(wallet);
				repo.save(dcustomer);
			}
		} catch (InvalidInputException e) {
			throw new InvalidInputException();
		}
		return dcustomer;

	}

	public Customer withdrawAmount(String mobileNo, BigDecimal balance)
			throws InsufficientBalanceException, SQLException {
		Customer wcustomer = repo.findOne(mobileNo);
		System.out.println("source:" + wcustomer);
		try {
			if (wcustomer != null) {
				Wallet iAmount = wcustomer.getWallet();
				int id = iAmount.getWalletId();
				BigDecimal updatedBalance = iAmount.getBalance().subtract(balance);
				Wallet wallet = new Wallet(updatedBalance, id);
				wcustomer.setWallet(wallet);
				repo.save(wcustomer);
				return wcustomer;
			} else {
				return null;
			}
		} catch (InsufficientBalanceException e) {
			throw new InsufficientBalanceException();
		}
	}





}
